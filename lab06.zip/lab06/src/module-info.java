module lab06 {
}