package lab06;

public interface Employee {
    double calculateSalary();
    void displayDetails();
}