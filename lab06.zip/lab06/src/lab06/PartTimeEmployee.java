package lab06;

public class PartTimeEmployee extends AbstractEmployee {
    private double hours;
    private double hourly_rate;
    
    public PartTimeEmployee(String name, JobType jobType, double hourly_rate, double hours) {
        super(name, jobType, 0);
        if (hourly_rate < 0) {
            throw new IllegalArgumentException("Hourly rate cannot be negative");
        }
        if (hours < 0) {
            throw new IllegalArgumentException("Hours worked cannot be negative");
        }
        this.hourly_rate = hourly_rate;
        this.hours = hours;
    }

    @Override
    public double calculateSalary() {
        return hours * hourly_rate;
    }
    
    @Override
    public void displayDetails() {
        System.out.printf("Name: %s | Job Type: %s | Salary: $%.2f (Rate: $%.2f/hour, Hours: %.1f)%n",
                name, jobType, calculateSalary(), hourly_rate, hours);
    }
}