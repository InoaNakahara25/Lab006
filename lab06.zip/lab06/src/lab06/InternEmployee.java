package lab06;

public class InternEmployee extends AbstractEmployee {
    private double stipend;
    
    public InternEmployee(String name, JobType jobType, double stipend) {
        super(name, jobType, 0);
        if (stipend < 0) {
            throw new IllegalArgumentException("Stipend cannot be negative");
        }
        this.stipend = stipend;
    }

    @Override
    public double calculateSalary() {
        return stipend;
    }
    
    @Override
    public void displayDetails() {
        System.out.printf("Name: %s | Job Type: %s | Salary: $%.2f (Stipend)%n",
                name, jobType, stipend);
    }
}