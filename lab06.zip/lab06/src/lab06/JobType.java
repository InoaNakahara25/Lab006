package lab06;

public enum JobType {  
    FULL_TIME, PART_TIME, INTERN  }